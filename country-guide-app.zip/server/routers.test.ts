import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(user?: AuthenticatedUser | null): TrpcContext {
  const defaultUser: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user: (user === undefined ? defaultUser : user) as any,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("countries router", () => {
  it("should list all countries", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const countries = await caller.countries.list();

    expect(Array.isArray(countries)).toBe(true);
    expect(countries.length).toBeGreaterThan(0);
    expect(countries[0]).toHaveProperty("id");
    expect(countries[0]).toHaveProperty("name");
    expect(countries[0]).toHaveProperty("description");
  });

  it("should get country by id", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // First get all countries to get a valid ID
    const countries = await caller.countries.list();
    expect(countries.length).toBeGreaterThan(0);

    const country = await caller.countries.getById({ id: countries[0].id });

    expect(country).toBeDefined();
    expect(country?.id).toBe(countries[0].id);
    expect(country?.name).toBe(countries[0].name);
  });

  it("should return undefined for non-existent country", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const country = await caller.countries.getById({ id: 99999 });

    expect(country).toBeUndefined();
  });
});

describe("appointments router", () => {
  it("should require authentication for listing appointments", async () => {
    const ctx = createAuthContext();
    ctx.user = null as any;
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.appointments.list();
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });

  it("should list user appointments", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const appointments = await caller.appointments.list();

    expect(Array.isArray(appointments)).toBe(true);
  });

  it("should create appointment for authenticated user", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Get a country first
    const countries = await caller.countries.list();
    expect(countries.length).toBeGreaterThan(0);

    const appointmentDate = new Date();
    appointmentDate.setDate(appointmentDate.getDate() + 7);

    const result = await caller.appointments.create({
      countryId: countries[0].id,
      appointmentDate,
      notes: "Test appointment",
    });

    expect(result).toBeDefined();
  });

  it("should require authentication for creating appointment", async () => {
    const ctx = createAuthContext();
    ctx.user = null as any;
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.appointments.create({
        countryId: 1,
        appointmentDate: new Date(),
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });
});

describe("reviews router", () => {
  it("should get reviews by country", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const countries = await caller.countries.list();
    expect(countries.length).toBeGreaterThan(0);

    const reviews = await caller.reviews.getByCountry({ countryId: countries[0].id });

    expect(Array.isArray(reviews)).toBe(true);
  });

  it("should create review for authenticated user", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const countries = await caller.countries.list();
    expect(countries.length).toBeGreaterThan(0);

    const result = await caller.reviews.create({
      countryId: countries[0].id,
      comment: "Great country!",
      rating: 5,
    });

    expect(result).toBeDefined();
  });

  it("should validate rating between 1-5", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const countries = await caller.countries.list();
    expect(countries.length).toBeGreaterThan(0);

    try {
      await caller.reviews.create({
        countryId: countries[0].id,
        comment: "Test",
        rating: 10,
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("BAD_REQUEST");
    }
  });

  it("should require authentication for creating review", async () => {
    const ctx = createAuthContext();
    ctx.user = null as any;
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.reviews.create({
        countryId: 1,
        comment: "Test",
        rating: 5,
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });

  it("should require non-empty comment", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const countries = await caller.countries.list();
    expect(countries.length).toBeGreaterThan(0);

    try {
      await caller.reviews.create({
        countryId: countries[0].id,
        comment: "",
        rating: 5,
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("BAD_REQUEST");
    }
  });
});
