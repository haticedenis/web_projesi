import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(user?: AuthenticatedUser | null): TrpcContext {
  const defaultUser: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user: (user === undefined ? defaultUser : user) as any,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("favorites router", () => {
  it("should require authentication for listing favorites", async () => {
    const ctx = createAuthContext();
    ctx.user = null as any;
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.favorites.list();
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });

  it("should list user favorites", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const favorites = await caller.favorites.list();

    expect(Array.isArray(favorites)).toBe(true);
  });

  it("should check if country is favorite", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const countries = await caller.countries.list();
    expect(countries.length).toBeGreaterThan(0);

    const isFav = await caller.favorites.isFavorite({ countryId: countries[0].id });

    expect(typeof isFav).toBe("boolean");
  });

  it("should add country to favorites", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const countries = await caller.countries.list();
    expect(countries.length).toBeGreaterThan(0);

    try {
      await caller.favorites.remove({ countryId: countries[0].id });
    } catch (e) {
      // ignore
    }

    const result = await caller.favorites.add({ countryId: countries[0].id });

    expect(result).toBeDefined();

    const isFav = await caller.favorites.isFavorite({ countryId: countries[0].id });
    expect(isFav).toBe(true);
  });

  it("should not allow adding duplicate favorites", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const countries = await caller.countries.list();
    expect(countries.length).toBeGreaterThan(1);

    try {
      await caller.favorites.remove({ countryId: countries[1].id });
    } catch (e) {
      // ignore
    }

    await caller.favorites.add({ countryId: countries[1].id });

    try {
      await caller.favorites.add({ countryId: countries[1].id });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toContain("zaten favorilerinizde");
    }
  });

  it("should remove country from favorites", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const countries = await caller.countries.list();
    expect(countries.length).toBeGreaterThan(2);

    try {
      await caller.favorites.remove({ countryId: countries[2].id });
    } catch (e) {
      // ignore
    }

    await caller.favorites.add({ countryId: countries[2].id });
    let isFav = await caller.favorites.isFavorite({ countryId: countries[2].id });
    expect(isFav).toBe(true);

    await caller.favorites.remove({ countryId: countries[2].id });
    isFav = await caller.favorites.isFavorite({ countryId: countries[2].id });
    expect(isFav).toBe(false);
  });

  it("should require authentication for adding favorites", async () => {
    const ctx = createAuthContext();
    ctx.user = null as any;
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.favorites.add({ countryId: 1 });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });

  it("should require authentication for removing favorites", async () => {
    const ctx = createAuthContext();
    ctx.user = null as any;
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.favorites.remove({ countryId: 1 });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });
});
