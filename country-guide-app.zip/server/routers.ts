import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getAllCountries, getCountryById, getAppointmentsByUserId, getReviewsByCountryId, createAppointment, createReview, deleteAppointment, deleteReview, getFavoritesByUserId, isFavorite, addFavorite, removeFavorite } from "./db";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  countries: router({
    list: publicProcedure.query(async () => {
      return await getAllCountries();
    }),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await getCountryById(input.id);
      }),
  }),

  appointments: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await getAppointmentsByUserId(ctx.user.id);
    }),
    create: protectedProcedure
      .input(z.object({
        countryId: z.number(),
        appointmentDate: z.date(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const country = await getCountryById(input.countryId);
        
        const result = await createAppointment({
          userId: ctx.user.id,
          countryId: input.countryId,
          appointmentDate: input.appointmentDate,
          notes: input.notes,
        });
        
        await notifyOwner({
          title: "Yeni Randevu Oluşturuldu",
          content: `${ctx.user.name} ${country?.name || "bir ülke"} için randevu oluşturdu. Tarih: ${input.appointmentDate.toLocaleDateString("tr-TR")}`
        });
        
        return result;
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await deleteAppointment(input.id);
      }),
  }),

  reviews: router({
    getByCountry: publicProcedure
      .input(z.object({ countryId: z.number() }))
      .query(async ({ input }) => {
        return await getReviewsByCountryId(input.countryId);
      }),
    create: protectedProcedure
      .input(z.object({
        countryId: z.number(),
        comment: z.string().min(1),
        rating: z.number().min(1).max(5),
      }))
      .mutation(async ({ ctx, input }) => {
        return await createReview({
          userId: ctx.user.id,
          countryId: input.countryId,
          comment: input.comment,
          rating: input.rating,
        });
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await deleteReview(input.id);
      }),
  }),

  favorites: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const favoriteRecords = await getFavoritesByUserId(ctx.user.id);
      const countryIds = favoriteRecords.map(f => f.countryId);
      
      if (countryIds.length === 0) return [];
      
      const allCountries = await getAllCountries();
      return allCountries.filter(c => countryIds.includes(c.id));
    }),
    isFavorite: protectedProcedure
      .input(z.object({ countryId: z.number() }))
      .query(async ({ ctx, input }) => {
        return await isFavorite(ctx.user.id, input.countryId);
      }),
    add: protectedProcedure
      .input(z.object({ countryId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const alreadyFavorite = await isFavorite(ctx.user.id, input.countryId);
        if (alreadyFavorite) {
          throw new Error("Bu ulke zaten favorilerinizde");
        }
        return await addFavorite({
          userId: ctx.user.id,
          countryId: input.countryId,
        });
      }),
    remove: protectedProcedure
      .input(z.object({ countryId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return await removeFavorite(ctx.user.id, input.countryId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
