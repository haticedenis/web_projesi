# Country Guide App - TODO

## Veritabanı & Backend
- [x] Ülke tablosu oluştur (id, name, description, imageUrl, population, capital, vb.)
- [x] Randevu tablosu oluştur (id, userId, countryId, date, time, notes, status)
- [x] Yorum tablosu oluştur (id, userId, countryId, comment, rating, createdAt)
- [x] Veritabanı şeması push et (pnpm db:push)
- [x] Ülke query helper oluştur
- [x] Randevu query helper oluştur
- [x] Yorum query helper oluştur
- [x] tRPC procedure'ları oluştur (ülkeler, randevular, yorumlar)
- [x] Randevu oluşturulduğunda site sahibine bildirim gönder

## Frontend - Tasarım & Layout
- [x] Tema konfigürasyonu (koyu arka plan, teal-turuncu gradyan)
- [x] Global CSS ve Tailwind konfigürasyonu
- [x] Tipografi ayarları (bold, sans-serif, beyaz)
- [x] Anasayfa layout oluştur
- [x] Navigasyon bileşeni oluştur

## Frontend - Ülke Sayfaları
- [x] Ülke slider/carousel bileşeni oluştur (anasayfa)
- [x] Ülke detay sayfası oluştur
- [x] Ülke listesi sayfası oluştur
- [x] Ülke görselleri ve bilgileri göster

## Frontend - Randevu Sistemi
- [x] Randevu formu oluştur
- [x] Randevu listesi sayfası oluştur (kullanıcı randevuları)
- [x] Randevu oluştur/sil/güncelle işlemleri
- [x] Randevu tarihi ve saati seçimi

## Frontend - Yorum Sistemi
- [x] Yorum formu oluştur
- [x] Yorum listesi göster (ülke detay sayfasında)
- [x] Yorum oluştur/sil işlemleri
- [x] Yorum derecelendirmesi (rating)

## Testing & Deployment
- [x] Vitest testleri yaz
- [x] Tüm özellikler test et
- [ ] Checkpoint oluştur
- [ ] Deployment hazırlığı


## Favoriler Sistemi
- [x] Favoriler tablosu oluştur (id, userId, countryId, createdAt)
- [x] Veritabanı şeması push et
- [x] Favori query helper'ları oluştur
- [x] tRPC procedure'ları oluştur (favori ekle, sil, listele)
- [x] Ülke detay sayfasına "Favorilere Ekle" butonu ekle
- [x] Favorilere ekle/çıkar toggle işlevi

## Profil Sayfası
- [x] Profil sayfası oluştur
- [x] Kullanıcı bilgileri göster
- [x] Favori ülkeleri listele
- [x] Profil sayfasına navigasyon ekle
- [x] Favori ülkeleri kaldırma özelliği

## Testing
- [x] Favoriler API testleri yaz
- [x] Profil sayfası testleri yaz


## Tasarım Güncellemesi
- [x] Global CSS'i açık arka plan, gri tonlar, kırmızı accent'e göre güncelle
- [x] Tema konfigürasyonunu light mode'a çevir
- [x] Anasayfa tasarımını yenile (modern, minimalist)
- [x] Navigasyon tasarımını güncelle (kırmızı CTA butonları)
- [x] Resim gösterme sorunu çöz
- [x] Tüm sayfaları responsive olarak test et
