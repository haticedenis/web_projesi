import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const countries = [
  {
    name: "Türkiye",
    description: "Asya ve Avrupa'nın kesiştiği noktada yer alan Türkiye, zengin tarihi, kültürü ve doğal güzellikleriyle ünlüdür. Kapadokya'nın peri bacaları, Ege'nin turkuaz suları ve İstanbul'un canlı atmosferi ziyaretçileri büyüler.",
    imageUrl: "https://images.unsplash.com/photo-1564507592333-c60657eea523?w=800&h=600&fit=crop",
    capital: "Ankara",
    population: "85 Milyon",
    region: "Orta Doğu & Avrupa",
    language: "Türkçe",
    currency: "Türk Lirası (TL)"
  },
  {
    name: "İtalya",
    description: "Sanat, tarih ve lezzetli mutfağıyla ünlü İtalya, Roma'nın antik harikalarından Venedik'in kanallarına kadar unutulmaz deneyimler sunar. Toscana'nın şarap bağları ve Amalfi kıyısı doğa severler için cennet.",
    imageUrl: "https://images.unsplash.com/photo-1552832860-cfb67165eaf0?w=800&h=600&fit=crop",
    capital: "Roma",
    population: "59 Milyon",
    region: "Avrupa",
    language: "İtalyanca",
    currency: "Euro (€)"
  },
  {
    name: "Japonya",
    description: "Geleneksel samuray kültürü ile modern teknolojinin mükemmel uyumu Japonya'yı benzersiz kılar. Tokyo'nun neon ışıkları, Kyoto'nun antik tapınaklarından Fuji Dağı'nın kar tepesine kadar her şey harika.",
    imageUrl: "https://images.unsplash.com/photo-1540959375944-7049f642e9a9?w=800&h=600&fit=crop",
    capital: "Tokyo",
    population: "125 Milyon",
    region: "Asya",
    language: "Japonca",
    currency: "Japon Yeni (¥)"
  },
  {
    name: "Fransa",
    description: "Aşk ve sanatın şehri Paris'ten Provence'ın lav tarlalarına kadar Fransa, romantizm ve kültürün sembolüdür. Eiffel Kulesi, Louvre Müzesi ve Fransız mutfağı dünya çapında ünlüdür.",
    imageUrl: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800&h=600&fit=crop",
    capital: "Paris",
    population: "67 Milyon",
    region: "Avrupa",
    language: "Fransızca",
    currency: "Euro (€)"
  },
  {
    name: "Brezilya",
    description: "Amazon Ormanı'ndan Rio de Janeiro'nun plajlarına kadar Brezilya, doğal güzelliklerin ve canlı kültürün bir mozaiğidir. Karnaval, futbol ve samba müziği Brezilya'nın ruhunu yansıtır.",
    imageUrl: "https://images.unsplash.com/photo-1483729558449-99ddc60c9b13?w=800&h=600&fit=crop",
    capital: "Brasília",
    population: "215 Milyon",
    region: "Güney Amerika",
    language: "Portekizce",
    currency: "Brezilya Reali (R$)"
  },
  {
    name: "Mısır",
    description: "Antik medeniyetin beşiği Mısır, Giza Piramitleri ve Nil Nehri'nin etrafında oluşturulmuş binlerce yıllık tarihi sunar. Kahire'nin enerji dolu sokaklarından Asvan'ın sakin nehir yolculuklarına kadar her an büyüleyici.",
    imageUrl: "https://images.unsplash.com/photo-1504681869696-d977211a0f78?w=800&h=600&fit=crop",
    capital: "Kahire",
    population: "104 Milyon",
    region: "Afrika",
    language: "Arapça",
    currency: "Mısır Poundu (£)"
  },
  {
    name: "İspanya",
    description: "Flamenco dansı, Gaudí'nin mimarileri ve Akdeniz'in güneşi İspanya'yı Avrupa'nın en canlı ülkelerinden biri yapar. Barcelona'dan Seville'e kadar her şehir kendi hikayesini anlatır.",
    imageUrl: "https://images.unsplash.com/photo-1469022563149-aa64dbd37dae?w=800&h=600&fit=crop",
    capital: "Madrid",
    population: "47 Milyon",
    region: "Avrupa",
    language: "İspanyolca",
    currency: "Euro (€)"
  },
  {
    name: "Tayland",
    description: "Budist tapınaklarının altın çatılarından Bangkok'un kaotik pazarlarına kadar Tayland, Asya'nın en büyüleyici destinasyonlarından biridir. Phuket'in plajları ve Chiang Mai'nin dağları doğa severler için ideal.",
    imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop",
    capital: "Bangkok",
    population: "70 Milyon",
    region: "Güneydoğu Asya",
    language: "Tayca",
    currency: "Tayland Bahtu (฿)"
  }
];

async function seedCountries() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  try {
    for (const country of countries) {
      await connection.execute(
        'INSERT INTO countries (name, description, imageUrl, capital, population, region, language, currency) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [country.name, country.description, country.imageUrl, country.capital, country.population, country.region, country.language, country.currency]
      );
      console.log(`✓ ${country.name} eklendi`);
    }
    console.log('\n✓ Tüm ülkeler başarıyla eklendi!');
  } catch (error) {
    console.error('Hata:', error);
  } finally {
    await connection.end();
  }
}

seedCountries();
