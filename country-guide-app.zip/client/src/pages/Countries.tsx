import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ArrowLeft, MapPin, Users, Search } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";

export default function Countries() {
  const [, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");

  const { data: countries = [], isLoading } = trpc.countries.list.useQuery();

  const filteredCountries = countries.filter((country) =>
    country.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    country.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-accent mx-auto mb-4"></div>
          <p className="text-foreground">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center gap-4 h-16">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-foreground/70 hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Geri</span>
          </button>
          <h1 className="text-2xl font-bold text-foreground flex-1">Tüm Ülkeler</h1>
        </div>
      </div>

      {/* Content */}
      <div className="container py-12">
        {/* Search Bar */}
        <div className="mb-12">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-foreground/40" />
            <input
              type="text"
              placeholder="Ülke ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-card/50 backdrop-blur border border-border rounded-lg pl-12 pr-4 py-3 text-foreground placeholder-foreground/40 focus:outline-none focus:ring-2 focus:ring-accent"
            />
          </div>
        </div>

        {/* Countries Grid */}
        {filteredCountries.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-foreground/70 text-lg">
              {searchTerm ? "Arama sonucu bulunamadı" : "Ülke bulunamadı"}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCountries.map((country) => (
              <div
                key={country.id}
                className="group relative bg-card/50 backdrop-blur border border-border rounded-xl overflow-hidden hover:border-accent transition-all duration-300 cursor-pointer glow-effect hover:glow-accent"
                onClick={() => navigate(`/country/${country.id}`)}
              >
                {country.imageUrl && (
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={country.imageUrl}
                      alt={country.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
                  </div>
                )}

                <div className="p-6">
                  <h3 className="text-2xl font-bold text-foreground mb-2">
                    {country.name}
                  </h3>
                  <p className="text-sm text-foreground/70 mb-4 line-clamp-3">
                    {country.description}
                  </p>

                  <div className="space-y-2 mb-4 text-sm text-foreground/60">
                    {country.capital && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-accent" />
                        <span>Başkent: {country.capital}</span>
                      </div>
                    )}
                    {country.population && (
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-accent" />
                        <span>Nüfus: {country.population}</span>
                      </div>
                    )}
                    {country.region && (
                      <div className="flex items-center gap-2">
                        <span className="text-accent">◆</span>
                        <span>Bölge: {country.region}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <Button
                      className="flex-1 bg-accent/20 hover:bg-accent/40 text-accent border border-accent/50"
                      variant="outline"
                    >
                      Detaylar
                    </Button>
                    {isAuthenticated && (
                      <Button
                        className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/country/${country.id}?tab=appointment`);
                        }}
                      >
                        Randevu
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
