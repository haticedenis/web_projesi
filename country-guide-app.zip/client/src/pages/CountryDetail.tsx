import { useEffect, useState } from "react";
import { useLocation, useRoute } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ArrowLeft, MapPin, Users, Globe, DollarSign, MessageCircle, Star } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { toast } from "sonner";

export default function CountryDetail() {
  const [, navigate] = useLocation();
  const [match, params] = useRoute("/country/:id");
  const { user, isAuthenticated } = useAuth();
  const countryId = params?.id ? parseInt(params.id) : null;

  const [activeTab, setActiveTab] = useState("info");
  const [appointmentDate, setAppointmentDate] = useState("");
  const [appointmentTime, setAppointmentTime] = useState("");
  const [appointmentNotes, setAppointmentNotes] = useState("");
  const [reviewComment, setReviewComment] = useState("");
  const [reviewRating, setReviewRating] = useState(5);

  const { data: isFav = false } = trpc.favorites.isFavorite.useQuery(
    { countryId: countryId || 0 },
    { enabled: !!countryId && isAuthenticated }
  );

  const { data: country, isLoading: countryLoading } = trpc.countries.getById.useQuery(
    { id: countryId || 0 },
    { enabled: !!countryId }
  );

  const { data: reviews = [], refetch: refetchReviews } = trpc.reviews.getByCountry.useQuery(
    { countryId: countryId || 0 },
    { enabled: !!countryId }
  );

  const createAppointmentMutation = trpc.appointments.create.useMutation({
    onSuccess: () => {
      toast.success("Randevu başarıyla oluşturuldu!");
      setAppointmentDate("");
      setAppointmentTime("");
      setAppointmentNotes("");
      setActiveTab("info");
    },
    onError: (error) => {
      toast.error(error.message || "Randevu oluşturulamadı");
    },
  });

  const addFavoriteMutation = trpc.favorites.add.useMutation({
    onSuccess: () => {
      toast.success("Favorilere eklendi!");
    },
    onError: (error) => {
      toast.error(error.message || "Favorilere eklenemedi");
    },
  });

  const removeFavoriteMutation = trpc.favorites.remove.useMutation({
    onSuccess: () => {
      toast.success("Favorilerden kaldırıldı!");
    },
    onError: (error) => {
      toast.error(error.message || "Favorilerden kaldırılamadı");
    },
  });

  const createReviewMutation = trpc.reviews.create.useMutation({
    onSuccess: () => {
      toast.success("Yorum başarıyla eklendi!");
      setReviewComment("");
      setReviewRating(5);
      refetchReviews();
    },
    onError: (error) => {
      toast.error(error.message || "Yorum eklenemedi");
    },
  });

  const handleCreateAppointment = () => {
    if (!appointmentDate) {
      toast.error("Lütfen bir tarih seçin");
      return;
    }

    const dateTime = new Date(`${appointmentDate}T${appointmentTime || "10:00"}`);
    
    createAppointmentMutation.mutate({
      countryId: countryId || 0,
      appointmentDate: dateTime,
      notes: appointmentNotes,
    });
  };

  const handleCreateReview = () => {
    if (!reviewComment.trim()) {
      toast.error("Lütfen bir yorum yazın");
      return;
    }

    createReviewMutation.mutate({
      countryId: countryId || 0,
      comment: reviewComment,
      rating: reviewRating,
    });
  };

  if (countryLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-accent mx-auto mb-4"></div>
          <p className="text-foreground">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!country) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-foreground text-lg mb-4">Ülke bulunamadı</p>
          <Button onClick={() => navigate("/")} className="bg-accent hover:bg-accent/90">
            Anasayfaya Dön
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center gap-4 h-16">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-foreground/70 hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Geri</span>
          </button>
          <h1 className="text-2xl font-bold text-foreground flex-1">{country.name}</h1>
        </div>
      </div>

      {/* Hero Image */}
      {country.imageUrl && (
        <div className="relative h-96 overflow-hidden">
          <img
            src={country.imageUrl}
            alt={country.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
        </div>
      )}

      {/* Content */}
      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Info Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
              {country.capital && (
                <div className="bg-card/50 backdrop-blur border border-border rounded-lg p-4 glow-effect">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="w-5 h-5 text-accent" />
                    <p className="text-sm text-foreground/60">Başkent</p>
                  </div>
                  <p className="text-lg font-semibold text-foreground">{country.capital}</p>
                </div>
              )}
              {country.population && (
                <div className="bg-card/50 backdrop-blur border border-border rounded-lg p-4 glow-effect">
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="w-5 h-5 text-accent" />
                    <p className="text-sm text-foreground/60">Nüfus</p>
                  </div>
                  <p className="text-lg font-semibold text-foreground">{country.population}</p>
                </div>
              )}
              {country.region && (
                <div className="bg-card/50 backdrop-blur border border-border rounded-lg p-4 glow-effect">
                  <div className="flex items-center gap-2 mb-2">
                    <Globe className="w-5 h-5 text-accent" />
                    <p className="text-sm text-foreground/60">Bölge</p>
                  </div>
                  <p className="text-lg font-semibold text-foreground">{country.region}</p>
                </div>
              )}
              {country.currency && (
                <div className="bg-card/50 backdrop-blur border border-border rounded-lg p-4 glow-effect">
                  <div className="flex items-center gap-2 mb-2">
                    <DollarSign className="w-5 h-5 text-accent" />
                    <p className="text-sm text-foreground/60">Para Birimi</p>
                  </div>
                  <p className="text-lg font-semibold text-foreground">{country.currency}</p>
                </div>
              )}
            </div>

            {/* Tabs */}
            <div className="flex gap-4 border-b border-border mb-8">
              <button
                onClick={() => setActiveTab("info")}
                className={`pb-4 px-2 font-semibold transition-colors ${
                  activeTab === "info"
                    ? "text-accent border-b-2 border-accent"
                    : "text-foreground/60 hover:text-foreground"
                }`}
              >
                Bilgiler
              </button>
              <button
                onClick={() => setActiveTab("reviews")}
                className={`pb-4 px-2 font-semibold transition-colors flex items-center gap-2 ${
                  activeTab === "reviews"
                    ? "text-accent border-b-2 border-accent"
                    : "text-foreground/60 hover:text-foreground"
                }`}
              >
                <MessageCircle className="w-4 h-4" />
                Yorumlar ({reviews.length})
              </button>
            </div>

            {/* Tab Content */}
            {activeTab === "info" && (
              <div className="prose prose-invert max-w-none">
                <p className="text-lg text-foreground/80 leading-relaxed mb-6">
                  {country.description}
                </p>
                {country.language && (
                  <div className="bg-card/50 backdrop-blur border border-border rounded-lg p-4 mb-6">
                    <p className="text-sm text-foreground/60 mb-1">Dil</p>
                    <p className="text-foreground font-semibold">{country.language}</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === "reviews" && (
              <div className="space-y-6">
                {reviews.length === 0 ? (
                  <p className="text-foreground/60 text-center py-8">
                    Henüz yorum yapılmamış. İlk yorum yapan siz olun!
                  </p>
                ) : (
                  reviews.map((review) => (
                    <div
                      key={review.id}
                      className="bg-card/50 backdrop-blur border border-border rounded-lg p-6 glow-effect"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="font-semibold text-foreground">Anonim Kullanıcı</p>
                          <p className="text-sm text-foreground/60">
                            {new Date(review.createdAt).toLocaleDateString("tr-TR")}
                          </p>
                        </div>
                        <div className="flex gap-1">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < review.rating
                                  ? "fill-accent text-accent"
                                  : "text-foreground/30"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-foreground/80">{review.comment}</p>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Appointment Form */}
            {isAuthenticated ? (
              <div className="bg-card/50 backdrop-blur border border-border rounded-lg p-6 glow-effect">
                <h3 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-accent" />
                  Randevu Oluştur
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Tarih
                    </label>
                    <input
                      type="date"
                      value={appointmentDate}
                      onChange={(e) => setAppointmentDate(e.target.value)}
                      className="w-full bg-background border border-border rounded-lg px-3 py-2 text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Saat
                    </label>
                    <input
                      type="time"
                      value={appointmentTime}
                      onChange={(e) => setAppointmentTime(e.target.value)}
                      className="w-full bg-background border border-border rounded-lg px-3 py-2 text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Notlar (İsteğe bağlı)
                    </label>
                    <textarea
                      value={appointmentNotes}
                      onChange={(e) => setAppointmentNotes(e.target.value)}
                      placeholder="Randevunuz hakkında notlar..."
                      className="w-full bg-background border border-border rounded-lg px-3 py-2 text-foreground focus:outline-none focus:ring-2 focus:ring-accent resize-none"
                      rows={3}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground"
                      onClick={handleCreateAppointment}
                      disabled={createAppointmentMutation.isPending}
                    >
                      {createAppointmentMutation.isPending ? "Oluşturuluyor..." : "Randevu Oluştur"}
                    </Button>
                    <Button
                      variant="outline"
                      className={`flex-1 ${
                        isFav
                          ? "bg-accent/20 hover:bg-accent/40 text-accent border-accent/50"
                          : "bg-background border-border hover:border-accent"
                      }`}
                      onClick={() => {
                        if (isFav) {
                          removeFavoriteMutation.mutate({ countryId: countryId || 0 });
                        } else {
                          addFavoriteMutation.mutate({ countryId: countryId || 0 });
                        }
                      }}
                      disabled={addFavoriteMutation.isPending || removeFavoriteMutation.isPending}
                    >
                      {isFav ? "❤️ Favorilerde" : "🤍 Favorilere Ekle"}
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-card/50 backdrop-blur border border-border rounded-lg p-6 glow-effect text-center">
                <p className="text-foreground/70 mb-4">
                  Randevu oluşturmak için giriş yapmanız gerekir.
                </p>
                <Button
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  onClick={() => (window.location.href = getLoginUrl())}
                >
                  Giriş Yap
                </Button>
              </div>
            )}

            {/* Review Form */}
            {isAuthenticated ? (
              <div className="bg-card/50 backdrop-blur border border-border rounded-lg p-6 glow-effect">
                <h3 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-accent" />
                  Yorum Yap
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Puanlama
                    </label>
                    <div className="flex gap-2">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <button
                          key={i}
                          onClick={() => setReviewRating(i + 1)}
                          className="transition-transform hover:scale-110"
                        >
                          <Star
                            className={`w-6 h-6 ${
                              i < reviewRating
                                ? "fill-accent text-accent"
                                : "text-foreground/30"
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Yorum
                    </label>
                    <textarea
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      placeholder="Bu ülke hakkında ne düşünüyorsunuz?"
                      className="w-full bg-background border border-border rounded-lg px-3 py-2 text-foreground focus:outline-none focus:ring-2 focus:ring-accent resize-none"
                      rows={4}
                    />
                  </div>
                  <Button
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                    onClick={handleCreateReview}
                    disabled={createReviewMutation.isPending}
                  >
                    {createReviewMutation.isPending ? "Gönderiliyor..." : "Yorum Gönder"}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="bg-card/50 backdrop-blur border border-border rounded-lg p-6 glow-effect text-center">
                <p className="text-foreground/70 mb-4">
                  Yorum yapmak için giriş yapmanız gerekir.
                </p>
                <Button
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  onClick={() => (window.location.href = getLoginUrl())}
                >
                  Giriş Yap
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
