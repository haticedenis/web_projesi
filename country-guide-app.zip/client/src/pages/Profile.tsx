import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Heart, MapPin, Users, Globe, DollarSign, Trash2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Profile() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated, loading, logout } = useAuth();

  const { data: favorites = [], isLoading, refetch } = trpc.favorites.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const removeFavoriteMutation = trpc.favorites.remove.useMutation({
    onSuccess: () => {
      toast.success("Favori kaldırıldı");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Favori kaldırılamadı");
    },
  });

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  if (loading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-accent mx-auto mb-4"></div>
          <p className="text-foreground">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-foreground text-lg mb-4">Bu sayfaya erişmek için giriş yapmanız gerekir</p>
          <Button onClick={() => navigate("/")} className="bg-accent hover:bg-accent/90">
            Anasayfaya Dön
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center gap-4 h-16">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-foreground/70 hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Geri</span>
          </button>
          <h1 className="text-2xl font-bold text-foreground flex-1">Profilim</h1>
        </div>
      </div>

      {/* Content */}
      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* User Info */}
          <div className="lg:col-span-1">
            <div className="bg-card/50 backdrop-blur border border-border rounded-lg p-6 glow-effect">
              <div className="text-center mb-6">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-accent to-secondary mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl font-bold text-accent-foreground">
                    {user?.name?.charAt(0).toUpperCase() || "U"}
                  </span>
                </div>
                <h2 className="text-2xl font-bold text-foreground mb-1">{user?.name}</h2>
                <p className="text-foreground/60">{user?.email}</p>
              </div>

              <div className="space-y-3 mb-6 pb-6 border-b border-border">
                <div className="text-sm text-foreground/60">
                  <p className="font-semibold text-foreground mb-1">Üyelik Tarihi</p>
                  <p>
                    {user?.createdAt
                      ? new Date(user.createdAt).toLocaleDateString("tr-TR", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })
                      : "-"}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Button
                  className="w-full bg-accent/20 hover:bg-accent/40 text-accent border border-accent/50"
                  variant="outline"
                  onClick={() => navigate("/appointments")}
                >
                  Randevularım
                </Button>
                <Button
                  className="w-full bg-destructive/20 hover:bg-destructive/40 text-destructive border border-destructive/50"
                  variant="outline"
                  onClick={handleLogout}
                >
                  Çıkış Yap
                </Button>
              </div>
            </div>
          </div>

          {/* Favorites */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <h2 className="text-3xl font-bold text-foreground flex items-center gap-2 mb-6">
                <Heart className="w-8 h-8 text-accent fill-accent" />
                Favori Ülkelerim
              </h2>

              {favorites.length === 0 ? (
                <div className="bg-card/50 backdrop-blur border border-border rounded-lg p-12 text-center glow-effect">
                  <Heart className="w-16 h-16 text-foreground/30 mx-auto mb-4" />
                  <p className="text-foreground/70 text-lg mb-6">
                    Henüz favori ülke eklemediniz
                  </p>
                  <Button
                    className="bg-accent hover:bg-accent/90 text-accent-foreground"
                    onClick={() => navigate("/countries")}
                  >
                    Ülkeleri Keşfet
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {favorites.map((country) => (
                    <div
                      key={country.id}
                      className="group relative bg-card/50 backdrop-blur border border-border rounded-xl overflow-hidden hover:border-accent transition-all duration-300 glow-effect hover:glow-accent"
                    >
                      {country.imageUrl && (
                        <div className="relative h-40 overflow-hidden">
                          <img
                            src={country.imageUrl}
                            alt={country.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
                        </div>
                      )}

                      <div className="p-6">
                        <h3 className="text-xl font-bold text-foreground mb-2">
                          {country.name}
                        </h3>
                        <p className="text-sm text-foreground/70 mb-4 line-clamp-2">
                          {country.description}
                        </p>

                        <div className="space-y-2 mb-4 text-sm text-foreground/60">
                          {country.capital && (
                            <div className="flex items-center gap-2">
                              <MapPin className="w-4 h-4 text-accent" />
                              <span>{country.capital}</span>
                            </div>
                          )}
                          {country.population && (
                            <div className="flex items-center gap-2">
                              <Users className="w-4 h-4 text-accent" />
                              <span>{country.population}</span>
                            </div>
                          )}
                        </div>

                        <div className="flex gap-2">
                          <Button
                            className="flex-1 bg-accent/20 hover:bg-accent/40 text-accent border border-accent/50"
                            variant="outline"
                            onClick={() => navigate(`/country/${country.id}`)}
                          >
                            Detaylar
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            className="text-destructive hover:text-destructive"
                            onClick={() => {
                              if (confirm("Bu ülkeyi favorilerden çıkarmak istediğinizden emin misiniz?")) {
                                removeFavoriteMutation.mutate({ countryId: country.id });
                              }
                            }}
                            disabled={removeFavoriteMutation.isPending}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
