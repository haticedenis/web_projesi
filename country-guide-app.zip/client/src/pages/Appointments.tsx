import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar, MapPin, Trash2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Appointments() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated, loading } = useAuth();

  const { data: appointments = [], isLoading, refetch } = trpc.appointments.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const deleteAppointmentMutation = trpc.appointments.delete.useMutation({
    onSuccess: () => {
      toast.success("Randevu başarıyla silindi");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Randevu silinemedi");
    },
  });

  if (loading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-accent mx-auto mb-4"></div>
          <p className="text-foreground">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-foreground text-lg mb-4">Bu sayfaya erişmek için giriş yapmanız gerekir</p>
          <Button onClick={() => navigate("/")} className="bg-accent hover:bg-accent/90">
            Anasayfaya Dön
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center gap-4 h-16">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-foreground/70 hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Geri</span>
          </button>
          <h1 className="text-2xl font-bold text-foreground flex-1">Randevularım</h1>
        </div>
      </div>

      {/* Content */}
      <div className="container py-12">
        {appointments.length === 0 ? (
          <div className="text-center py-20">
            <Calendar className="w-16 h-16 text-foreground/30 mx-auto mb-4" />
            <p className="text-foreground/70 text-lg mb-6">
              Henüz randevu oluşturmadınız
            </p>
            <Button
              className="bg-accent hover:bg-accent/90 text-accent-foreground"
              onClick={() => navigate("/")}
            >
              Ülkeleri Keşfet
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {appointments.map((appointment) => (
              <div
                key={appointment.id}
                className="bg-card/50 backdrop-blur border border-border rounded-lg p-6 glow-effect hover:border-accent transition-all duration-300"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-sm text-foreground/60 mb-1">Randevu Tarihi</p>
                    <p className="text-lg font-semibold text-foreground">
                      {new Date(appointment.appointmentDate).toLocaleDateString("tr-TR", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      appointment.status === "confirmed"
                        ? "bg-green-500/20 text-green-400"
                        : appointment.status === "cancelled"
                        ? "bg-red-500/20 text-red-400"
                        : "bg-yellow-500/20 text-yellow-400"
                    }`}
                  >
                    {appointment.status === "confirmed"
                      ? "Onaylandı"
                      : appointment.status === "cancelled"
                      ? "İptal Edildi"
                      : "Beklemede"}
                  </span>
                </div>

                {appointment.notes && (
                  <div className="mb-4">
                    <p className="text-sm text-foreground/60 mb-1">Notlar</p>
                    <p className="text-foreground/80">{appointment.notes}</p>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => navigate(`/country/${appointment.countryId}`)}
                  >
                    <MapPin className="w-4 h-4 mr-2" />
                    Ülkeyi Gör
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="text-destructive hover:text-destructive"
                    onClick={() => {
                      if (confirm("Bu randevuyu silmek istediğinizden emin misiniz?")) {
                        deleteAppointmentMutation.mutate({ id: appointment.id });
                      }
                    }}
                    disabled={deleteAppointmentMutation.isPending}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
