import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, MapPin, Users, Globe, Heart } from "lucide-react";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const { data: countries = [], isLoading: countriesLoading } = trpc.countries.list.useQuery();

  const nextSlide = () => {
    if (countries.length > 0) {
      setCurrentSlide((prev) => (prev + 1) % countries.length);
    }
  };

  const prevSlide = () => {
    if (countries.length > 0) {
      setCurrentSlide((prev) => (prev - 1 + countries.length) % countries.length);
    }
  };

  const currentCountry = countries[currentSlide];

  if (authLoading || countriesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-accent mx-auto mb-4"></div>
          <p className="text-foreground">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <Globe className="w-7 h-7 text-accent" />
            <h1 className="text-2xl font-bold text-foreground">Global Gezgin</h1>
          </div>
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <div className="flex items-center gap-3">
                <span className="text-sm text-foreground/70">{user?.name}</span>
                <Button
                  size="sm"
                  className="bg-accent hover:bg-accent/90 text-accent-foreground rounded-full"
                  onClick={() => navigate("/profile")}
                >
                  Profilim
                </Button>
              </div>
            ) : (
              <Button
                size="sm"
                className="bg-accent hover:bg-accent/90 text-accent-foreground rounded-full"
                onClick={() => (window.location.href = getLoginUrl())}
              >
                Kaydet
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Slider Section */}
      <section className="relative min-h-[calc(100vh-64px)] flex items-center justify-center overflow-hidden bg-white">
        {currentCountry && (
          <div className="relative w-full h-full flex items-center justify-center">
            {/* Slide Image Background */}
            {currentCountry.imageUrl && (
              <div
                className="absolute inset-0 bg-cover bg-center opacity-40"
                style={{ backgroundImage: `url(${currentCountry.imageUrl})` }}
              />
            )}

            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-r from-white via-white/80 to-white/40" />

            {/* Content */}
            <div className="relative z-10 container flex items-center justify-between gap-12">
              <div className="max-w-2xl">
                <div className="mb-4 flex items-center gap-2">
                  <div className="text-sm font-semibold text-accent">VISIT</div>
                  <div className="h-px w-8 bg-accent"></div>
                </div>
                <h2 className="text-7xl md:text-8xl font-bold mb-6 text-foreground leading-tight">
                  {currentCountry.name}
                </h2>
                <p className="text-base text-foreground/70 mb-8 leading-relaxed max-w-xl">
                  {currentCountry.description}
                </p>

                <div className="grid grid-cols-2 gap-6 mb-8 max-w-md">
                  {currentCountry.capital && (
                    <div>
                      <p className="text-xs text-foreground/60 uppercase tracking-wider mb-2">Başkent</p>
                      <p className="text-lg font-bold text-foreground">{currentCountry.capital}</p>
                    </div>
                  )}
                  {currentCountry.population && (
                    <div>
                      <p className="text-xs text-foreground/60 uppercase tracking-wider mb-2">Nüfus</p>
                      <p className="text-lg font-bold text-foreground">{currentCountry.population}</p>
                    </div>
                  )}
                </div>

                <div className="flex gap-4">
                  <Button
                    className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 rounded-full font-semibold"
                    onClick={() => navigate(`/country/${currentCountry.id}`)}
                  >
                    Detayları Gör
                  </Button>
                  <Button
                    variant="outline"
                    className="px-8 rounded-full font-semibold border-2 border-foreground/20 hover:border-foreground/40"
                    onClick={() => {
                      if (!isAuthenticated) {
                        window.location.href = getLoginUrl();
                      } else {
                        navigate(`/country/${currentCountry.id}?tab=appointment`);
                      }
                    }}
                  >
                    Randevu Al
                  </Button>
                </div>
              </div>

              {/* Slide Image */}
              {currentCountry.imageUrl && (
                <div className="hidden lg:block relative w-1/3 h-3/4">
                  <img
                    src={currentCountry.imageUrl}
                    alt={currentCountry.name}
                    className="w-full h-full object-cover rounded-3xl shadow-lg"
                  />
                </div>
              )}
            </div>

            {/* Slider Controls */}
            <button
              onClick={prevSlide}
              className="absolute left-8 top-1/2 -translate-y-1/2 z-20 bg-foreground/10 hover:bg-foreground/20 text-foreground p-3 rounded-full transition-all duration-300"
              aria-label="Önceki ülke"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-8 top-1/2 -translate-y-1/2 z-20 bg-foreground/10 hover:bg-foreground/20 text-foreground p-3 rounded-full transition-all duration-300"
              aria-label="Sonraki ülke"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Slide Indicators */}
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex gap-2">
              {countries.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`rounded-full transition-all duration-300 ${
                    index === currentSlide
                      ? "bg-accent w-8 h-2"
                      : "bg-foreground/30 w-2 h-2 hover:bg-foreground/50"
                  }`}
                  aria-label={`Slide ${index + 1}`}
                />
              ))}
            </div>

            {/* Slide Counter */}
            <div className="absolute top-8 right-8 z-20 text-foreground/60 text-sm font-semibold">
              {String(currentSlide + 1).padStart(2, '0')} / {String(countries.length).padStart(2, '0')}
            </div>
          </div>
        )}
      </section>

      {/* Featured Countries Section */}
      <section className="py-24 bg-background">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl font-bold mb-4 text-foreground">
              Dünyayı Keşfet
            </h2>
            <p className="text-lg text-foreground/60 max-w-2xl mx-auto">
              Farklı ülkeleri keşfedin, randevu oluşturun ve diğer gezginlerin yorumlarını okuyun.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {countries.slice(0, 6).map((country) => (
              <div
                key={country.id}
                className="group relative bg-white rounded-2xl overflow-hidden border border-border hover:border-accent transition-all duration-300 cursor-pointer hover:shadow-lg"
                onClick={() => navigate(`/country/${country.id}`)}
              >
                {country.imageUrl && (
                  <div className="relative h-56 overflow-hidden bg-muted">
                    <img
                      src={country.imageUrl}
                      alt={country.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                  </div>
                )}

                <div className="p-6">
                  <h3 className="text-2xl font-bold text-foreground mb-2">
                    {country.name}
                  </h3>
                  <p className="text-sm text-foreground/60 mb-4 line-clamp-2">
                    {country.description}
                  </p>

                  <div className="space-y-2 mb-6 text-sm text-foreground/70">
                    {country.capital && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-accent" />
                        <span>{country.capital}</span>
                      </div>
                    )}
                    {country.population && (
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-accent" />
                        <span>{country.population}</span>
                      </div>
                    )}
                  </div>

                  <Button
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground rounded-full font-semibold"
                    size="sm"
                  >
                    Detayları Gör
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button
              variant="outline"
              className="px-8 rounded-full border-2 border-foreground/20 hover:border-foreground/40 font-semibold"
              onClick={() => navigate("/countries")}
            >
              Tüm Ülkeleri Gör
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-accent text-accent-foreground">
        <div className="container text-center">
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            Seyahat Etmeye Hazır mısın?
          </h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto opacity-90">
            Dünya çapında ülkeleri keşfet, randevu oluştur ve benzersiz deneyimler yaşa.
          </p>
          <Button
            className="bg-white text-accent hover:bg-white/90 px-8 rounded-full font-semibold"
            onClick={() => {
              if (!isAuthenticated) {
                window.location.href = getLoginUrl();
              } else {
                navigate("/countries");
              }
            }}
          >
            Şimdi Başla
          </Button>
        </div>
      </section>
    </div>
  );
}
